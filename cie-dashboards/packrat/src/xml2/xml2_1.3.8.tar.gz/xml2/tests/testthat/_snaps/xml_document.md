# print method is correct

    Code
      print(x)
    Output
      {html_document}
      <html xmlns:og="http://ogp.me/ns#" xmlns:fb="http://www.facebook.com/2008/fbml">
      [1] <head>\n<script type="text/javascript">var ue_t0=window.ue_t0||+new Date( ...
      [2] <body id="styleguide-v2" class="fixed">\n<script>\n    if (typeof uet ==  ...

