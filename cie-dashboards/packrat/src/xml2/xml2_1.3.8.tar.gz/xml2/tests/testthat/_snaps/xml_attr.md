# xml_attrs<- modifies all attributes

    Code
      xml_attrs(docs) <- "test"
    Condition
      Error in `xml_attrs<-`:
      ! `test` must be a list of named character vectors.

