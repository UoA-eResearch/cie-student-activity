# error if missing ns spec

    Code
      xml_name(bars, ns)
    Condition
      Error in `xml_name()`:
      ! Couldn't find prefix for url http://bar.com

