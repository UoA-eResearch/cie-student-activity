# xml_child() errors if more than one search is given

    Code
      xml_child(x, 1:2)
    Condition
      Error in `xml_child()`:
      ! `1` and `2` must be of length 1.

