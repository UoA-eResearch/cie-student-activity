library(testthat)
library(fontawesome)

test_check("fontawesome")
