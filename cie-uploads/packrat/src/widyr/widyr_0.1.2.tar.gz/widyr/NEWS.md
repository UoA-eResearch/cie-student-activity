# widyr 0.1.2

* Fixes to be compatible with tidyr v1.0.0, while also being reverse-compatible with previous versions of tidyr.
* Fix intro vignette index entry

# widyr 0.1.1

* Added `pairwise_delta` function for Burrows' delta
* Added `pairwise_pmi` for pairwise mutual information
* Added `widely_svd` for performing singular value decomposition then re-tidying
* Removed methods from DESCRIPTION

# widyr 0.1.0

* Initial release of package
* Only functions are the pairwise_ collection of functions, as well as the widely and squarely adverbs.
