# vertices() works

    Can't recycle `name` (size 2) to match `foo` (size 3).

