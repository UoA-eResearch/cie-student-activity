# tidy.geeglm

    Code
      td2 <- tidy(fit, conf.int = FALSE, exponentiate = TRUE)
    Condition
      Warning:
      Coefficients will be exponentiated, but the model didn't use a `log` or `logit` link.

