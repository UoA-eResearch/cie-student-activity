# augment.speedglm errors

    Code
      augment(fit)
    Condition
      Error in `augment()`:
      ! No `augment()` method for objects of class <speedglm/speedlm>.

