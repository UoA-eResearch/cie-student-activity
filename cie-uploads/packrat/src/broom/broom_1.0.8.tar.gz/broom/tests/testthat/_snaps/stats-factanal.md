# augment.factanal works

    Code
      augment(fit_none)
    Condition
      Error in `augment()`:
      ! Cannot augment <factanal> objects fit with `scores = "none"`.

