# tidy.vars

    Code
      .res <- tidy(fit, conf.int = TRUE)
    Condition
      Warning:
      Confidence intervals are not supported for <varest> objects.
      i The `conf.level` argument will be ignored.

