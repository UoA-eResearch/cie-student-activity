# tidy_xyz

    Code
      tidy(b)
    Condition
      Error in `tidy_xyz()`:
      ! To tidy an xyz list, the length of element `x` must equal the number of rows of element `z`, and the length of element `y` must equal the number of columns of element `z`.

---

    Code
      tidy(c)
    Condition
      Error in `tidy_xyz()`:
      ! To tidy an xyz list, the length of element `x` must equal the number of rows of element `z`, and the length of element `y` must equal the number of columns of element `z`.

---

    Code
      tidy(d)
    Condition
      Error in `tidy_xyz()`:
      ! `z` must be a matrix.

