# glance.rqs

    Code
      glance(fit)
    Condition
      Error in `glance()`:
      ! `glance()` cannot handle objects of class <rqs>, i.e. models with more than one tau value.
      i Please use a purrr `map()`-based workflow with <rq> models instead.

