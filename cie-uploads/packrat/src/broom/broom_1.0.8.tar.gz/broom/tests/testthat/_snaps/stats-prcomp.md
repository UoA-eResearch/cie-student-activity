# tidy.prcomp

    Code
      tidy(pc, matrix = c("d", "u"))
    Condition
      Error in `tidy()`:
      ! Must select a single matrix to tidy.

