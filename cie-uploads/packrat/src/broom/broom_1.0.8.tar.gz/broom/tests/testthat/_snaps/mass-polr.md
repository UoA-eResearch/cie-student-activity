# tidy.polr messages informatively

    Code
      .res <- tidy(fit, p.values = TRUE)
    Message
      p-values can presently only be returned for models that contain no categorical variables with more than two levels.

