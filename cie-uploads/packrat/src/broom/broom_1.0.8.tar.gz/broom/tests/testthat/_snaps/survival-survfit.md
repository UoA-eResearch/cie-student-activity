# glance.survfit

    Code
      glance(sfit)
    Condition
      Error in `glance()`:
      ! Cannot `glance()` a multi-strata <survfit> object.

---

    Code
      glance(fit2)
    Condition
      Error in `glance()`:
      ! Cannot `glance()` a multi-state <survfit> object.

