# augment.Mclust

    Code
      augment(fit, 1:10)
    Condition
      Error in `augment()`:
      ! `data` must be a data frame or matrix.

