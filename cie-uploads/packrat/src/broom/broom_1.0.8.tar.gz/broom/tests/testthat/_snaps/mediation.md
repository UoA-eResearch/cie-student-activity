# tidy.mediate errors informatively

    Code
      tidy(psych_mediate)
    Condition
      Error in `tidy()`:
      ! No tidy method for objects of class <mediate> from the psych package.
      i The `tidy.mediate()` method is intended for <mediate> objects from the mediation package.

