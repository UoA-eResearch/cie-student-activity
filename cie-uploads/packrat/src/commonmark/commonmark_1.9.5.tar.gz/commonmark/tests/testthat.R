library(testthat)
library(commonmark)

test_check("commonmark")
