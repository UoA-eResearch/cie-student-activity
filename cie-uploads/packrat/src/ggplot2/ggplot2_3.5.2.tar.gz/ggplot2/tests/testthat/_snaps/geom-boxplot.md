# boxplots with a group size >1 error

    Can only draw one boxplot per group.
    i Did you forget `aes(group = ...)`?

