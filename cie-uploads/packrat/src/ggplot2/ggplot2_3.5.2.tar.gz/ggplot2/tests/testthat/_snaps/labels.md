# plot.tag.position rejects invalid input

    The `plot.tag.position` theme element must be a <character/numeric/integer> object.

---

    `plot.tag.position` must be one of "topleft", "top", "topright", "left", "right", "bottomleft", "bottom", or "bottomright", not "foobar".

