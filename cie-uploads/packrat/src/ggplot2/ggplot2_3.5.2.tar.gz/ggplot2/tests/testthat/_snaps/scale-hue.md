# scale_hue() checks the type input

    `type` must be a character vector or a list of character vectors.

