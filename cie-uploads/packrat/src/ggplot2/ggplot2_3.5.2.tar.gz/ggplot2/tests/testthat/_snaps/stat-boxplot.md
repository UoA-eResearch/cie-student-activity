# stat_boxplot drops missing rows with a warning

    Removed 10 rows containing missing values or values outside the scale range (`stat_boxplot()`).

---

    Removed 10 rows containing missing values or values outside the scale range (`stat_boxplot()`).

# stat_boxplot errors with missing x/y aesthetics

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `setup_params()`:
    ! `stat_boxplot()` requires an x or y aesthetic.

