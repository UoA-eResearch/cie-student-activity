# sec_axis checks the user input

    Secondary axes must be specified using `sec_axis()`.

---

    Transformation for secondary axes must be a function.

---

    Transformation for secondary axes must be strictly monotonic.

