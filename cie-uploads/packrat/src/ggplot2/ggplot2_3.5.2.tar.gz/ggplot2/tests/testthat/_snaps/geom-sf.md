# errors are correctly triggered

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! `geom_sf()` can only be used with `coord_sf()`.

---

    Both `position` and `nudge_x`/`nudge_y` are supplied.
    i Only use one approach to alter the position.

---

    Both `position` and `nudge_x`/`nudge_y` are supplied.
    i Only use one approach to alter the position.

---

    Removed 1 row containing missing values or values outside the scale range (`geom_sf()`).

