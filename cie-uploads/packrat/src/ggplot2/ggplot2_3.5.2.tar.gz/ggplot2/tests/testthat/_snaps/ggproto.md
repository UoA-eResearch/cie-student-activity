# construction checks input

    All members of a <ggproto> object must be named.

---

    All members of a <ggproto> object must be named.

---

    `_inherit` must be a <ggproto> object, not a <data.frame> object.

